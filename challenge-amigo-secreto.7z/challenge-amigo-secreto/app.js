let amigos = [];

function adicionarAmigo() {
    let input = document.getElementById("amigo");
    let nome = input.value.trim();
//nao permite nome vazio
    if (nome === "") {
        alert("Insira um nome.");
        return;
    }
//nao permite nome duplicado
    if (amigos.includes(nome)) {
        alert("Esse nome já foi adicionado.");
        return;
    }

    amigos.push(nome);

    atualizarLista();
//limpa a barra de digitacao
    input.value = "";
}

function atualizarLista() {
    let lista = document.getElementById("listaAmigos");

    lista.innerHTML = "";

    for (let i = 0; i < amigos.length; i++) {
        let li = document.createElement("li");
        li.textContent = amigos[i];
        lista.appendChild(li);
    }
}

function sortearAmigo() {
    //verifivando se ha amigos na lista
    if (amigos.length === 0) {
        alert("Adicione pelo menos um amigo antes de sortear.");
        return;
    }

    //gera indice aleatório do tamanho do array
    let indiceSorteado = Math.floor(Math.random() * amigos.length);

    //nome sorteado
    let amigoSorteado = amigos[indiceSorteado];

    //mostra o nome sorteado
    let resultado = document.getElementById("resultado");
    resultado.innerHTML = `<li>🎉 Amigo sorteado: <strong>${amigoSorteado}</strong> 🎉</li>`;
}